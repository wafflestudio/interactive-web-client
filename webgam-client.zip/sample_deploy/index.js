const webgamBead3 = document.querySelector("#webgam-bead-3");

webgamBead3.addEventListener("click", (e) => {
  alert("clicked");
});
