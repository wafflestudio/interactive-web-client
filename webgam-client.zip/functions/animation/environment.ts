export const friction = 0.5;
export const fps = 1;
