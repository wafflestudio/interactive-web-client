import { DragAction } from "../modules/drag";

export type ActionType = DragAction;
