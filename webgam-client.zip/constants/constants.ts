export const categoryList = [
  { id: 0, navigator: "샘플 페이지", name: "샘플 페이지", path: "sample" },
  { id: 1, navigator: "신규 페이지", name: "NEW!", path: "new" },
  { id: 2, navigator: "핫한 페이지", name: "지금 핫한 페이지", path: "hot" },
];

export const RECT = "rect";
export const ELLIPSE = "ellipse";
export const IMAGE = "image";
